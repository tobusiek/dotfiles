vim.opt.colorcolumn = "88"

vim.opt.relativenumber = true

vim.opt.smartindent = true

vim.opt.wrap = false

vim.keymap.set("x", "<leader>p", "\"_dP")
vim.keymap.set("n", "<leader>y", "\"+y")
vim.keymap.set("v", "<leader>y", "\"+y")

vim.keymap.set("i", "<C-c>", "<Esc>")
vim.keymap.set("n", "Q", "<nop>")

