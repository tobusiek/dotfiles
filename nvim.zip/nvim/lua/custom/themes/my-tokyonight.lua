---@type Base46Table
local M = {}

M.base_30 = {
  white = "#c0caf5",
  darker_black = "#16161e", -- LSP?CMD Pop-ups, Tree BG
  black = "#1a1b26", --  nvim bg, CMP BG, Icons/Headers FG
  black2 = "#1f2336", -- Tabline BG, Cursor Lines, Selections
  one_bg = "#24283b", -- Pop-up Menu BG, Statusline Icon FG
  one_bg2 = "#414868", -- Tabline Inactive BG, Indent Line Context Start
  one_bg3 = "#353b45", -- Tabline Toggle/Newt Btn, Borders
  grey = "#40486a", -- Line Nr, Scrollbar, Indent Line Hover
  grey_fg = "#565f89", -- Comment
  grey_fg2 = "#4f5779", -- Unused
  light_grey = "#545c7e", -- Diff Change, Tabline Inactive FG
  red = "#f7768e", -- Diff Delete, Diag Error
  baby_pink = "#DE8C92", -- Some Dev Icons
  pink = "#ff75a0", -- Indicators
  line = "#32333e", -- for lines like vertsplit, Win Sep, Indent Line
  green = "#9ece6a", -- Diff Add, Diag Indo, Indicators
  vibrant_green = "#73daca", -- Some Dev Icons
  nord_blue = "#80a8fd", -- Indicators
  blue = "#7aa2f7", --  UI Elements, Dev/CMP Icons
  yellow = "#e0af68", -- Diag Warn
  sun = "#EBCB8B", -- Dev Icons
  purple = "#bb9af7", -- Diag Hint, Dev/CMP Icons
  dark_purple = "#9d7cd8", -- Some Dev Icons
  teal = "#1abc9c", -- Dev/CMP Icons
  orange = "#ff9e64", -- Diff Mod
  cyan = "#7dcfff", -- Dev/CMP Icons
  statusline_bg = "#1d1e29", -- Statusline
  lightbg = "#32333e", -- Statusline Components
  pmenu_bg = "#7aa2f7", -- Pop-up Menu Selection
  folder_bg = "#7aa2f7", -- Nvimtree Items
}

M.base_16 = {
  base00 = "#1a1b26", -- Neovim Default Background
  base01 = "#16161e", -- Lighter Background (Used for status bars, line numbers and folding marks)
  base02 = "#2f3549", -- Selection Background (Visual Mode)
  base03 = "#444b6a", -- Comments, Invisibles, Line Highlighting, Special Kets, Sings, Fold bg
  base04 = "#787c99", -- Dark Foreground, Dnf Underline (Used for status bars)
  base05 = "#a9b1d6", -- Default Background (for text), Var, References Caret, Delimiters, Operators
  base06 = "#cbccd1", -- Light Foreground (Not often used)
  base07 = "#d5d6db", -- Light Foreground, Cmp Icons (Not often used)
  base08 = "#73daca", -- Variables, Identifiers, Filed, Name Space, Error, Spell XML Tags, Markup Link Text, Markup Lists, Diff Deleted
  base09 = "#ff9e64", -- Integers, Boolean, Constants, XML Attributes, Markup Link Url, Inc Search
  base0A = "#7aa2f7", -- Classes, Attribute, Type, Repeat, Tag, Todo, Markup Bold, Search Text Background
  base0B = "#9ece6a", -- Strings, Symbols, Inherited Class, MarkupCode, Diff Inserted
  base0C = "#b4f9f8", -- Constructor, Special, Fold Column, Support, Regular Expressions, Escape Characters, Markup Quotes
  base0D = "#9d7cd8", -- Functions, Methods, Attributes IDs, Headings
  base0E = "#bb9af7", -- Keywords, Storage, Selector, Markup Italic, Diff Changed
  base0F = "#f7768e", -- Delimites, Special Char, Deprecated, Opening/Closing Embedded Language Tags, e.g. <?php ?>
}

M.polish_hl = {
  ["@punctuation.bracket"] = { fg = M.base_30.cyan },
  ["@punctuation.delimiter"] = { fg = M.base_30.cyan },
  ["@constant"] = { fg = M.base_30.sun },
  ["@constructor"] = { fg = "#2ac3de" },
  ["@function"] = { fg = M.base_30.blue },
  ["@function.macro"] = { fg = M.base_16.base08 },
  ["@function.call"] = { fg = M.base_30.blue },
  ["@method"] = { fg = M.base_30.blue },
  ["@method.call"] = { fg = M.base_30.blue },
  ["@parameter"] = { fg = M.base_30.white },
  ["@variable"] = { fg = M.base_30.white },
  ["@variable.builtin"] = { fg = M.base_16.base0F, italic = true },
  ["@type"] = { fg = "#2ac3de" },
  ["Type"] = { fg = "#2ac3de" },
  ["@type.builtin"] = { fg = "#2ac3de" },
  -- ["@type.definition"] = { fg = M.base_30.blue },
  ["@operator"] = { fg = M.base_16.base08 },
  ["@attribute"] = { fg = "#eda1f0" },
}

M.type = "dark"

M = require("base46").override_theme(M, "my-tokyonight")

return M
