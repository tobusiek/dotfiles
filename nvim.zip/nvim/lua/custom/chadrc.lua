---@type ChadrcConfig
local M = {}

M.ui = {
  theme = "clean-tokyonight",
}

M.plugins = "custom.plugins"
M.mappings = require "custom.mappings"

return M
